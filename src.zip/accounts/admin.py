from django.contrib import admin
from .models import profile
# Register your models here.
#admin.site.register(Tags)
admin.site.register(profile)
